/**
 * Chrome SSH & SFTP Extension - WebSocket Bridge Server
 * Author: livekadeh (https://github.com/livekadeh)
 * High-performance, low-latency bridge between WebSocket clients and SSH2/SFTP
 */

const http = require('http');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');
const crypto = require('crypto');
const express = require('express');
const { WebSocketServer } = require('ws');
const { Client } = require('ssh2');
const cors = require('cors');
require('dotenv').config();

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

const activeSftpSessions = new Map();

const app = express();
app.use(cors());
app.use(express.json({ limit: '500mb' }));
app.use(express.urlencoded({ limit: '500mb', extended: true }));

app.get('/', (req, res) => {
  res.json({
    status: 'online',
    service: 'LiveKadeh SSH & SFTP Bridge Server',
    version: '1.5.1',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    endpoints: {
      health: '/health',
      downloads: '/downloads',
      websocket: `ws://${req.headers.host || 'localhost:' + PORT}/ws`
    }
  });
});

// Serve compiled desktop artifacts from dist directory
const distDir = path.resolve(__dirname, '../dist');
const rootDir = path.resolve(__dirname, '..');
app.use('/download', express.static(distDir));
app.use('/download', express.static(rootDir));

// Web download portal
app.get('/downloads', (req, res) => {
  const files = [
    {
      name: 'LiveKadeh-SSH-SFTP-Portable-v1.5.1.exe',
      title: 'نسخه پرتابل ویندوز (Desktop Portable x64)',
      path: path.join(distDir, 'LiveKadeh-SSH-SFTP-Portable-v1.5.1.exe'),
      url: '/download/LiveKadeh-SSH-SFTP-Portable-v1.5.1.exe',
      badge: 'ویندوز x64'
    },
    {
      name: 'LiveKadeh-SSH-SFTP-Linux-v1.5.1.AppImage',
      title: 'نسخه دسکتاپ لینوکس (Linux AppImage x64)',
      path: path.join(distDir, 'LiveKadeh-SSH-SFTP-Linux-v1.5.1.AppImage'),
      url: '/download/LiveKadeh-SSH-SFTP-Linux-v1.5.1.AppImage',
      badge: 'لینوکس AppImage'
    },
    {
      name: 'LiveKadeh-SSH-SFTP-Mac-arm64-v1.5.1.zip',
      title: 'نسخه دسکتاپ مک (macOS Apple Silicon M1/M2/M3/M4)',
      path: path.join(distDir, 'LiveKadeh-SSH-SFTP-Mac-arm64-v1.5.1.zip'),
      url: '/download/LiveKadeh-SSH-SFTP-Mac-arm64-v1.5.1.zip',
      badge: 'مک Apple Silicon'
    },
    {
      name: 'LiveKadeh-SSH-SFTP-Mac-x64-v1.5.1.zip',
      title: 'نسخه دسکتاپ مک اینتل (macOS Intel x64)',
      path: path.join(distDir, 'LiveKadeh-SSH-SFTP-Mac-x64-v1.5.1.zip'),
      url: '/download/LiveKadeh-SSH-SFTP-Mac-x64-v1.5.1.zip',
      badge: 'مک Intel x64'
    },
    {
      name: 'livekadeh-ssh-sftp-extension-v1.5.1.zip',
      title: 'افزونه کروم (Chrome Extension ZIP)',
      path: path.join(rootDir, 'livekadeh-ssh-sftp-extension-v1.5.1.zip'),
      url: '/download/livekadeh-ssh-sftp-extension-v1.5.1.zip',
      badge: 'Chrome Extension'
    },
    {
      name: 'livekadeh-bridge-windows-x64-portable.zip',
      title: 'سرور بریج مستقل ویندوز (Bridge Server Windows x64)',
      path: path.join(rootDir, 'livekadeh-bridge-windows-x64-portable.zip'),
      url: '/download/livekadeh-bridge-windows-x64-portable.zip',
      badge: 'Windows Server'
    },
    {
      name: 'livekadeh-bridge-linux-x64.tar.gz',
      title: 'سرور بریج لینوکس (Bridge Server Linux x64)',
      path: path.join(rootDir, 'livekadeh-bridge-linux-x64.tar.gz'),
      url: '/download/livekadeh-bridge-linux-x64.tar.gz',
      badge: 'Linux Server'
    }
  ];

  const items = files.map(f => {
    let sizeStr = 'N/A';
    if (fs.existsSync(f.path)) {
      const bytes = fs.statSync(f.path).size;
      sizeStr = (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    }
    return `
      <div class="card">
        <div class="file-info">
          <div class="file-name"><span class="badge">${f.badge}</span> ${f.title}</div>
          <div class="file-meta">${f.name} &bull; <strong>${sizeStr}</strong></div>
        </div>
        <a href="${f.url}" class="btn-download" download>دانلود مستقیم</a>
      </div>
    `;
  }).join('');

  res.send(`<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>دانلود LiveKadeh SSH & SFTP Pro</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Tahoma, sans-serif; background: #0b0f19; color: #f1f5f9; padding: 32px 16px; margin: 0; }
    .container { max-width: 680px; margin: 0 auto; }
    h1 { font-size: 22px; color: #38bdf8; margin-bottom: 6px; display: flex; align-items: center; gap: 8px; }
    p.desc { font-size: 14px; color: #94a3b8; margin-top: 0; margin-bottom: 24px; }
    .card { background: #131b2e; border: 1px solid #1e293b; border-radius: 12px; padding: 16px 20px; margin-bottom: 14px; display: flex; align-items: center; justify-content: space-between; gap: 16px; transition: border-color 0.2s; }
    .card:hover { border-color: #38bdf8; }
    .file-name { font-weight: 600; font-size: 15px; color: #f8fafc; margin-bottom: 4px; }
    .file-meta { font-size: 12px; color: #94a3b8; font-family: monospace; }
    .badge { background: #0284c7; color: #fff; font-size: 11px; padding: 2px 8px; border-radius: 6px; font-weight: bold; margin-left: 6px; }
    .btn-download { background: #2563eb; color: #fff; text-decoration: none; padding: 10px 20px; border-radius: 8px; font-weight: 600; font-size: 13px; white-space: nowrap; transition: background 0.2s; }
    .btn-download:hover { background: #1d4ed8; }
  </style>
</head>
<body>
  <div class="container">
    <h1>⚡ پرتال دانلود LiveKadeh SSH & SFTP Pro</h1>
    <p class="desc">نسخه‌های رسمی کامپایل‌شده نسخه ۱.۴.۳ همراه با پشتیبانی کامل BiDi و فونت وزیر</p>
    ${items}
  </div>
</body>
</html>`);
});

app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    activeClients: wss.clients.size
  });
});

// HTTP SFTP Media Streaming Endpoint with Range / HTTP 206 support
app.get('/stream', (req, res) => {
  const { sessionId, path: filePath } = req.query;
  if (!sessionId || !filePath) {
    return res.status(400).send('Missing sessionId or path parameter');
  }

  const session = activeSftpSessions.get(sessionId);
  if (!session || !session.sftpSession) {
    return res.status(404).send('Active SFTP session not found or closed. Please reconnect.');
  }

  const sftp = session.sftpSession;

  sftp.stat(filePath, (err, stats) => {
    if (err) {
      return res.status(404).send('File not found or inaccessible: ' + err.message);
    }

    const isDir = (stats.mode & 0o170000) === 0o040000;
    if (isDir) {
      return res.status(400).send('Cannot stream directory');
    }

    const fileSize = stats.size;
    const range = req.headers.range;

    const ext = path.extname(filePath).toLowerCase().replace('.', '');
    const mimeTypes = {
      mp4: 'video/mp4',
      webm: 'video/webm',
      mov: 'video/quicktime',
      mkv: 'video/x-matroska',
      avi: 'video/x-msvideo',
      mp3: 'audio/mpeg',
      wav: 'audio/wav',
      ogg: 'audio/ogg',
      m4a: 'audio/mp4',
      aac: 'audio/aac',
      flac: 'audio/flac',
      png: 'image/png',
      jpg: 'image/jpeg',
      jpeg: 'image/jpeg',
      gif: 'image/gif',
      webp: 'image/webp',
      svg: 'image/svg+xml'
    };
    const contentType = mimeTypes[ext] || 'application/octet-stream';

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Range');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Content-Length, Accept-Ranges, Content-Disposition');
    res.setHeader('Accept-Ranges', 'bytes');

    if (req.query.download === '1' || req.query.download === 'true') {
      const safeFilename = path.basename(filePath);
      const encodedFilename = encodeURIComponent(safeFilename);
      res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}"; filename*=UTF-8''${encodedFilename}`);
    }

    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }

    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;

      if (start >= fileSize || end >= fileSize || start > end) {
        res.status(416).setHeader('Content-Range', `bytes */${fileSize}`).send('Requested range not satisfiable');
        return;
      }

      const chunksize = (end - start) + 1;
      res.status(206);
      res.setHeader('Content-Range', `bytes ${start}-${end}/${fileSize}`);
      res.setHeader('Content-Length', chunksize);
      res.setHeader('Content-Type', contentType);

      const stream = sftp.createReadStream(filePath, { start, end });
      stream.on('error', (sErr) => {
        if (!res.headersSent) res.status(500).send(sErr.message);
      });
      stream.pipe(res);
    } else {
      res.status(200);
      res.setHeader('Content-Length', fileSize);
      res.setHeader('Content-Type', contentType);

      const stream = sftp.createReadStream(filePath);
      stream.on('error', (sErr) => {
        if (!res.headersSent) res.status(500).send(sErr.message);
      });
      stream.pipe(res);
    }
  });
});

// Streaming upload endpoint for fast file write and cross-server transfers
app.put('/stream', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, PUT, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Range, Content-Type, Content-Length');

  const sessionId = req.query.sessionId;
  const filePath = req.query.path;

  if (!sessionId || !filePath) {
    return res.status(400).json({ success: false, error: 'Missing sessionId or path' });
  }

  const sftp = sftpSessions.get(sessionId);
  if (!sftp) {
    return res.status(404).json({ success: false, error: 'SFTP session not found or closed' });
  }

  const writeStream = sftp.createWriteStream(filePath);
  let hasClosed = false;

  req.pipe(writeStream);

  writeStream.on('close', () => {
    if (!hasClosed) {
      hasClosed = true;
      res.json({ success: true });
    }
  });

  writeStream.on('error', (err) => {
    if (!hasClosed && !res.headersSent) {
      hasClosed = true;
      res.status(500).json({ success: false, error: err.message });
    }
  });

  req.on('error', () => {
    writeStream.destroy();
  });
});

app.options('/stream', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, PUT, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Range, Content-Type, Content-Length');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Content-Length, Accept-Ranges, Content-Disposition');
  res.sendStatus(200);
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

console.log(`[Bridge Server] Initializing WebSocket SSH & SFTP Bridge on port ${PORT}...`);

wss.on('connection', (ws, req) => {
  const clientIp = req.socket.remoteAddress;
  console.log(`[WS] Client connected from ${clientIp}`);

  let sshClient = null;
  let sshStream = null;
  let sftpSession = null;
  let isConnected = false;
  let currentBridgeSessionId = null;
  const uploadHandles = new Map();
  const activeExternalWatchers = new Map();

  const safeSend = (obj) => {
    if (ws.readyState === ws.OPEN) {
      ws.send(JSON.stringify(obj));
    }
  };

  // Heartbeat ping
  const pingInterval = setInterval(() => {
    if (ws.readyState === ws.OPEN) {
      ws.ping();
    }
  }, 25000);

  const cleanupSSH = () => {
    uploadHandles.forEach((upload) => {
      if (sftpSession && upload.handle) {
        try { sftpSession.close(upload.handle, () => {}); } catch (e) {}
      }
    });
    uploadHandles.clear();

    activeExternalWatchers.forEach((item) => {
      if (item.watcher) {
        try { item.watcher.close(); } catch (e) {}
      }
    });
    activeExternalWatchers.clear();

    if (sshStream) {
      try { sshStream.end(); } catch (e) {}
      sshStream = null;
    }
    if (sftpSession) {
      try { sftpSession.end(); } catch (e) {}
      sftpSession = null;
    }
    if (sshClient) {
      try { sshClient.end(); } catch (e) {}
      sshClient = null;
    }
    if (currentBridgeSessionId) {
      activeSftpSessions.delete(currentBridgeSessionId);
      currentBridgeSessionId = null;
    }
    isConnected = false;
  };

  ws.on('message', (message) => {
    let msg;
    try {
      msg = JSON.parse(message.toString());
    } catch (err) {
      safeSend({ type: 'error', message: 'Invalid JSON payload: ' + err.message });
      return;
    }

    const type = msg.type;

    // --- PING / PONG ---
    if (type === 'ping') {
      safeSend({ type: 'pong', timestamp: Date.now() });
      return;
    }

    // --- SSH INITIALIZATION ---
    if (type === 'ssh-init') {
      cleanupSSH();
      const { host, port = 22, username, password, privateKey, passphrase, term = 'xterm-256color', cols = 80, rows = 24 } = msg;

      if (!host || !username) {
        safeSend({ type: 'ssh-status', status: 'error', message: 'Missing host or username' });
        return;
      }

      safeSend({ type: 'ssh-status', status: 'connecting', message: `Connecting to ${username}@${host}:${port}...` });

      sshClient = new Client();

      sshClient.on('ready', () => {
        isConnected = true;
        safeSend({ type: 'ssh-status', status: 'authenticated', message: 'SSH Authentication successful. Opening PTY shell...' });

        sshClient.shell({
          term: term,
          cols: parseInt(cols, 10) || 80,
          rows: parseInt(rows, 10) || 24
        }, (err, stream) => {
          if (err) {
            safeSend({ type: 'ssh-status', status: 'error', message: 'PTY Shell error: ' + err.message });
            cleanupSSH();
            return;
          }

          sshStream = stream;
          safeSend({ type: 'ssh-status', status: 'connected', message: 'Terminal ready' });

          stream.on('data', (data) => {
            safeSend({ type: 'ssh-output', data: data.toString('utf-8') });
          });

          stream.on('close', () => {
            safeSend({ type: 'ssh-status', status: 'disconnected', message: 'SSH session closed by remote host.' });
            cleanupSSH();
          });

          stream.stderr.on('data', (data) => {
            safeSend({ type: 'ssh-output', data: data.toString('utf-8') });
          });
        });
      });

      sshClient.on('error', (err) => {
        console.error(`[SSH Error] ${host}:`, err.message);
        safeSend({ type: 'ssh-status', status: 'error', message: 'SSH Connection failed: ' + err.message });
        cleanupSSH();
      });

      sshClient.on('close', () => {
        if (isConnected) {
          safeSend({ type: 'ssh-status', status: 'disconnected', message: 'SSH connection terminated.' });
        }
        cleanupSSH();
      });

      sshClient.on('keyboard-interactive', (name, instructions, instructionsLang, prompts, finish) => {
        if (password) {
          finish([password]);
        } else {
          finish([]);
        }
      });

      const connectConfig = {
        host,
        port: parseInt(port, 10) || 22,
        username,
        tryKeyboard: true,
        readyTimeout: 20000,
        keepaliveInterval: 10000
      };

      if (privateKey) {
        connectConfig.privateKey = privateKey;
        if (passphrase) connectConfig.passphrase = passphrase;
      } else if (password) {
        connectConfig.password = password;
      }

      try {
        sshClient.connect(connectConfig);
      } catch (err) {
        safeSend({ type: 'ssh-status', status: 'error', message: 'Failed to start SSH client: ' + err.message });
      }
      return;
    }

    // --- SSH INPUT ---
    if (type === 'ssh-input') {
      if (sshStream && sshStream.writable) {
        sshStream.write(msg.data);
      }
      return;
    }

    // --- SSH RESIZE ---
    if (type === 'ssh-resize') {
      if (sshStream && typeof sshStream.setWindow === 'function') {
        const cols = parseInt(msg.cols, 10) || 80;
        const rows = parseInt(msg.rows, 10) || 24;
        sshStream.setWindow(rows, cols, 0, 0);
      }
      return;
    }

    // --- SSH CLOSE ---
    if (type === 'ssh-close') {
      cleanupSSH();
      safeSend({ type: 'ssh-status', status: 'disconnected', message: 'Session closed by user.' });
      return;
    }

    // --- SFTP INITIALIZATION & COMMANDS ---
    if (type === 'sftp-init') {
      cleanupSSH();
      const { host, port = 22, username, password, privateKey, passphrase } = msg;

      safeSend({ type: 'sftp-status', status: 'connecting', message: `Opening SFTP connection to ${username}@${host}:${port}...` });

      sshClient = new Client();

      sshClient.on('ready', () => {
        sshClient.sftp((err, sftp) => {
          if (err) {
            safeSend({ type: 'sftp-status', status: 'error', message: 'SFTP subsystem error: ' + err.message });
            cleanupSSH();
            return;
          }

          sftpSession = sftp;
          isConnected = true;
          currentBridgeSessionId = crypto.randomBytes(16).toString('hex');
          activeSftpSessions.set(currentBridgeSessionId, { sftpSession, ws });

          safeSend({
            type: 'sftp-status',
            status: 'connected',
            message: 'SFTP Session Established',
            sessionId: currentBridgeSessionId
          });
        });
      });

      sshClient.on('error', (err) => {
        safeSend({ type: 'sftp-status', status: 'error', message: 'SFTP Connection failed: ' + err.message });
        cleanupSSH();
      });

      sshClient.on('close', () => {
        safeSend({ type: 'sftp-status', status: 'disconnected', message: 'SFTP connection closed' });
        cleanupSSH();
      });

      const connectConfig = {
        host,
        port: parseInt(port, 10) || 22,
        username,
        tryKeyboard: true,
        readyTimeout: 20000
      };

      if (privateKey) {
        connectConfig.privateKey = privateKey;
        if (passphrase) connectConfig.passphrase = passphrase;
      } else if (password) {
        connectConfig.password = password;
      }

      try {
        sshClient.connect(connectConfig);
      } catch (err) {
        safeSend({ type: 'sftp-status', status: 'error', message: err.message });
      }
      return;
    }

    // Helper for executing SFTP actions
    const checkSftp = (id) => {
      if (!sftpSession) {
        safeSend({ type: 'sftp-error', id, message: 'SFTP session is not active. Please connect first.' });
        return false;
      }
      return true;
    };

    // --- SFTP LIST DIRECTORY ---
    if (type === 'sftp-list') {
      const { path: dirPath = '.', id } = msg;
      if (!checkSftp(id)) return;

      sftpSession.readdir(dirPath, (err, list) => {
        if (err) {
          safeSend({ type: 'sftp-list-res', id, success: false, path: dirPath, error: err.message });
          return;
        }

        const files = list.map(item => ({
          filename: item.filename,
          longname: item.longname,
          attrs: {
            mode: item.attrs.mode,
            uid: item.attrs.uid,
            gid: item.attrs.gid,
            size: item.attrs.size,
            atime: item.attrs.atime,
            mtime: item.attrs.mtime,
            isDirectory: (item.attrs.mode & 0o40000) === 0o40000,
            isSymbolicLink: (item.attrs.mode & 0o120000) === 0o120000,
            isFile: (item.attrs.mode & 0o100000) === 0o100000,
            permissions: (item.attrs.mode & 0o777).toString(8)
          }
        })).sort((a, b) => {
          if (a.attrs.isDirectory && !b.attrs.isDirectory) return -1;
          if (!a.attrs.isDirectory && b.attrs.isDirectory) return 1;
          return a.filename.localeCompare(b.filename);
        });

        // Resolve absolute real path if needed
        sftpSession.realpath(dirPath, (rErr, realPath) => {
          safeSend({
            type: 'sftp-list-res',
            id,
            success: true,
            path: rErr ? dirPath : realPath,
            files
          });
        });
      });
      return;
    }

    // --- SFTP READ FILE ---
    if (type === 'sftp-read') {
      const { path: filePath, id } = msg;
      const requestedMax = Number(msg.maxBytes) || (500 * 1024 * 1024);
      const maxLimit = Math.min(requestedMax, 2048 * 1024 * 1024);
      if (!checkSftp(id)) return;

      sftpSession.stat(filePath, (sErr, stats) => {
        if (sErr) {
          safeSend({ type: 'sftp-read-res', id, success: false, error: sErr.message });
          return;
        }

        const isDir = (stats.mode & 0o170000) === 0o040000;
        if (isDir) {
          safeSend({ type: 'sftp-read-res', id, success: false, isDir: true, error: 'Target is a directory. Please use directory download (Zip).' });
          return;
        }

        if (stats.size > maxLimit) {
          safeSend({ type: 'sftp-read-res', id, success: false, error: `File too large (${(stats.size / 1024 / 1024).toFixed(2)} MB). Max limit is ${(maxLimit / 1024 / 1024).toFixed(0)} MB.` });
          return;
        }

        const readStream = sftpSession.createReadStream(filePath);
        const chunks = [];

        readStream.on('data', chunk => chunks.push(chunk));
        readStream.on('error', err => {
          safeSend({ type: 'sftp-read-res', id, success: false, error: err.message });
        });
        readStream.on('end', () => {
          const buffer = Buffer.concat(chunks);
          // Check if file is utf8 text or binary
          let isBinary = false;
          for (let i = 0; i < Math.min(buffer.length, 512); i++) {
            if (buffer[i] === 0) { isBinary = true; break; }
          }

          safeSend({
            type: 'sftp-read-res',
            id,
            success: true,
            path: filePath,
            size: stats.size,
            isBinary,
            content: isBinary ? buffer.toString('base64') : buffer.toString('utf-8')
          });
        });
      });
      return;
    }

    // --- SFTP WRITE / UPLOAD FILE ---
    if (type === 'sftp-write') {
      const { path: filePath, content, isBase64 = false, id } = msg;
      if (!checkSftp(id)) return;

      const buffer = isBase64 ? Buffer.from(content, 'base64') : Buffer.from(content, 'utf-8');
      const writeStream = sftpSession.createWriteStream(filePath);

      writeStream.on('error', err => {
        safeSend({ type: 'sftp-write-res', id, success: false, error: err.message });
      });

      writeStream.on('close', () => {
        safeSend({ type: 'sftp-write-res', id, success: true, path: filePath, size: buffer.length });
      });

      writeStream.end(buffer);
      return;
    }

    // --- SFTP CHUNKED UPLOAD ---
    if (type === 'sftp-chunk-init') {
      const { path: filePath, id } = msg;
      if (!checkSftp(id)) return;

      sftpSession.open(filePath, 'w', (err, handle) => {
        if (err) {
          safeSend({ type: 'sftp-chunk-init-res', id, success: false, error: err.message });
        } else {
          uploadHandles.set(id, { handle, offset: 0, path: filePath });
          safeSend({ type: 'sftp-chunk-init-res', id, success: true, uploadId: id });
        }
      });
      return;
    }

    if (type === 'sftp-chunk-write') {
      const { uploadId, chunk, offset, id } = msg;
      const upload = uploadHandles.get(uploadId);
      if (!upload) {
        safeSend({ type: 'sftp-chunk-write-res', id, success: false, error: 'Upload handle not found' });
        return;
      }
      const buffer = Buffer.from(chunk, 'base64');
      const pos = (offset !== undefined) ? offset : upload.offset;
      sftpSession.write(upload.handle, buffer, 0, buffer.length, pos, (err) => {
        if (err) {
          safeSend({ type: 'sftp-chunk-write-res', id, success: false, error: err.message });
        } else {
          upload.offset = pos + buffer.length;
          safeSend({ type: 'sftp-chunk-write-res', id, success: true, written: buffer.length });
        }
      });
      return;
    }

    if (type === 'sftp-chunk-end') {
      const { uploadId, id } = msg;
      const upload = uploadHandles.get(uploadId);
      if (!upload) {
        safeSend({ type: 'sftp-chunk-end-res', id, success: false, error: 'Upload handle not found' });
        return;
      }
      sftpSession.close(upload.handle, (err) => {
        uploadHandles.delete(uploadId);
        safeSend({ type: 'sftp-chunk-end-res', id, success: !err, path: upload.path, error: err ? err.message : null });
      });
      return;
    }

    // --- SFTP MKDIR ---
    if (type === 'sftp-mkdir') {
      const { path: dirPath, id } = msg;
      if (!checkSftp(id)) return;

      sftpSession.mkdir(dirPath, err => {
        safeSend({ type: 'sftp-mkdir-res', id, success: !err, path: dirPath, error: err ? err.message : null });
      });
      return;
    }

    // --- SFTP RMDIR (RECURSIVE DIRECTORY DELETION) ---
    if (type === 'sftp-rmdir') {
      const { path: dirPath, id } = msg;
      if (!checkSftp(id)) return;

      const escapeShell = (str) => "'" + str.replace(/'/g, "'\\''") + "'";

      const sftpRmdirRecursive = (targetDir, cb) => {
        sftpSession.readdir(targetDir, (err, list) => {
          if (err) {
            return sftpSession.rmdir(targetDir, cb);
          }

          const items = (list || []).filter(item => item.filename !== '.' && item.filename !== '..');
          if (items.length === 0) {
            return sftpSession.rmdir(targetDir, cb);
          }

          let remaining = items.length;
          let encounteredError = null;

          for (const item of items) {
            const itemPath = (targetDir.endsWith('/') ? targetDir : targetDir + '/') + item.filename;
            const isDir = item.attrs ? ((item.attrs.mode & 0o170000) === 0o040000) : false;

            const onDone = (delErr) => {
              if (delErr && !encounteredError) encounteredError = delErr;
              remaining--;
              if (remaining === 0) {
                if (encounteredError) return cb(encounteredError);
                sftpSession.rmdir(targetDir, cb);
              }
            };

            if (isDir) {
              sftpRmdirRecursive(itemPath, onDone);
            } else {
              sftpSession.unlink(itemPath, onDone);
            }
          }
        });
      };

      if (sshClient && isConnected) {
        const cmd = `rm -rf -- ${escapeShell(dirPath)}`;
        let stderr = '';
        let exitCode = null;
        let finished = false;

        sshClient.exec(cmd, (execErr, stream) => {
          if (execErr) {
            return sftpRmdirRecursive(dirPath, (err) => {
              safeSend({ type: 'sftp-rmdir-res', id, success: !err, path: dirPath, error: err ? err.message : null });
            });
          }

          const finish = (code) => {
            if (finished) return;
            finished = true;
            const finalCode = (typeof code === 'number') ? code : (typeof exitCode === 'number' ? exitCode : (stderr ? 1 : 0));
            if (finalCode === 0) {
              safeSend({ type: 'sftp-rmdir-res', id, success: true, path: dirPath, error: null });
            } else {
              sftpRmdirRecursive(dirPath, (err) => {
                safeSend({ type: 'sftp-rmdir-res', id, success: !err, path: dirPath, error: err ? (stderr || err.message) : null });
              });
            }
          };

          stream.on('data', () => {});
          stream.stderr.on('data', d => { stderr += d.toString(); });
          stream.on('exit', code => {
            exitCode = code;
            finish(code);
          });
          stream.on('close', code => {
            finish(code);
          });
          stream.resume();
        });
      } else {
        sftpRmdirRecursive(dirPath, (err) => {
          safeSend({ type: 'sftp-rmdir-res', id, success: !err, path: dirPath, error: err ? err.message : null });
        });
      }
      return;
    }

    // --- SFTP UNLINK (DELETE FILE) ---
    if (type === 'sftp-unlink') {
      const { path: filePath, id } = msg;
      if (!checkSftp(id)) return;

      sftpSession.unlink(filePath, err => {
        safeSend({ type: 'sftp-unlink-res', id, success: !err, path: filePath, error: err ? err.message : null });
      });
      return;
    }

    // --- SFTP RENAME / MOVE ---
    if (type === 'sftp-rename') {
      const { oldPath, newPath, id } = msg;
      if (!checkSftp(id)) return;

      sftpSession.rename(oldPath, newPath, err => {
        safeSend({ type: 'sftp-rename-res', id, success: !err, oldPath, newPath, error: err ? err.message : null });
      });
      return;
    }

    // --- SFTP COPY (RECURSIVE OR STREAMING) ---
    if (type === 'sftp-copy') {
      const { items, srcPath, destPath, id } = msg;
      if (!checkSftp(id)) return;

      const copyList = items && Array.isArray(items) && items.length > 0 
        ? items 
        : (srcPath && destPath ? [{ src: srcPath, dest: destPath }] : []);

      if (copyList.length === 0) {
        safeSend({ type: 'sftp-copy-res', id, success: false, error: 'No items specified for copy' });
        return;
      }

      const escapeShell = (str) => "'" + str.replace(/'/g, "'\\''") + "'";

      // Strategy 1: Fast server-side copy via SSH exec
      if (sshClient && isConnected) {
        const copyCmds = copyList.map(item => `cp -r -- ${escapeShell(item.src)} ${escapeShell(item.dest)}`).join(' && ');
        let stderr = '';
        let exitCode = null;
        let finished = false;

        sshClient.exec(copyCmds, (err, stream) => {
          if (err) {
            fallbackSftpCopy(err.message);
            return;
          }

          const finish = (code) => {
            if (finished) return;
            finished = true;
            const finalCode = (typeof code === 'number') ? code : (typeof exitCode === 'number' ? exitCode : (stderr ? 1 : 0));
            if (finalCode === 0) {
              safeSend({ type: 'sftp-copy-res', id, success: true, count: copyList.length });
            } else {
              fallbackSftpCopy(stderr || `Copy command exited with code ${finalCode}`);
            }
          };

          stream.on('data', () => {});
          stream.stderr.on('data', (d) => { stderr += d.toString(); });
          stream.on('exit', (code) => {
            exitCode = code;
            finish(code);
          });
          stream.on('close', (code) => {
            finish(code);
          });
          stream.resume();
        });
        return;
      }

      fallbackSftpCopy();

      // Strategy 2: Fallback pure SFTP recursive copy with safe atomic / chunked transfers
      function fallbackSftpCopy(originalError = null) {
        let index = 0;

        function copyNext() {
          if (index >= copyList.length) {
            safeSend({ type: 'sftp-copy-res', id, success: true, count: copyList.length });
            return;
          }

          const current = copyList[index++];
          sftpCopyItem(current.src, current.dest, (err) => {
            if (err) {
              safeSend({
                type: 'sftp-copy-res',
                id,
                success: false,
                error: err.message || originalError || 'Failed to copy item'
              });
              return;
            }
            copyNext();
          });
        }

        function sftpCopyFile(src, dest, cb) {
          sftpSession.stat(src, (stErr, stats) => {
            if (stErr) return cb(stErr);
            const fileSize = (stats && typeof stats.size === 'number') ? stats.size : 0;

            // In-memory read/write for files under 64MB - fast, atomic, zero stream deadlocks
            if (fileSize < 64 * 1024 * 1024) {
              sftpSession.readFile(src, (readErr, data) => {
                if (readErr) return cb(readErr);
                sftpSession.writeFile(dest, data, cb);
              });
              return;
            }

            // Chunked read/write for larger files
            sftpSession.open(src, 'r', (openErr, readHandle) => {
              if (openErr) return cb(openErr);
              sftpSession.open(dest, 'w', (wOpenErr, writeHandle) => {
                if (wOpenErr) {
                  sftpSession.close(readHandle, () => {});
                  return cb(wOpenErr);
                }

                const CHUNK_SIZE = 512 * 1024;
                const buf = Buffer.alloc(CHUNK_SIZE);
                let position = 0;

                function copyNextChunk() {
                  sftpSession.read(readHandle, buf, 0, CHUNK_SIZE, position, (rErr, bytesRead) => {
                    if (rErr) {
                      sftpSession.close(readHandle, () => {});
                      sftpSession.close(writeHandle, () => {});
                      return cb(rErr);
                    }
                    if (bytesRead === 0) {
                      sftpSession.close(readHandle, () => {});
                      sftpSession.close(writeHandle, (cErr) => cb(cErr));
                      return;
                    }

                    sftpSession.write(writeHandle, buf, 0, bytesRead, position, (wErr) => {
                      if (wErr) {
                        sftpSession.close(readHandle, () => {});
                        sftpSession.close(writeHandle, () => {});
                        return cb(wErr);
                      }
                      position += bytesRead;
                      copyNextChunk();
                    });
                  });
                }

                copyNextChunk();
              });
            });
          });
        }

        function sftpCopyItem(src, dest, cb) {
          sftpSession.stat(src, (sErr, stats) => {
            if (sErr) return cb(sErr);
            const isDir = (stats.mode & 0o170000) === 0o040000;
            if (!isDir) {
              sftpCopyFile(src, dest, cb);
            } else {
              sftpSession.mkdir(dest, () => {
                sftpSession.readdir(src, (rErr, list) => {
                  if (rErr) return cb(rErr);
                  const children = (list || []).filter(c => c.filename !== '.' && c.filename !== '..');
                  if (children.length === 0) return cb(null);
                  let pending = children.length;
                  let childError = null;
                  for (const child of children) {
                    const cSrc = (src.endsWith('/') ? src : src + '/') + child.filename;
                    const cDest = (dest.endsWith('/') ? dest : dest + '/') + child.filename;
                    sftpCopyItem(cSrc, cDest, (cErr) => {
                      if (cErr && !childError) childError = cErr;
                      pending--;
                      if (pending === 0) cb(childError);
                    });
                  }
                });
              });
            }
          });
        }

        copyNext();
      }
      return;
    }

    // --- SFTP MOVE (OS NATIVE OR SFTP FALLBACK) ---
    if (type === 'sftp-move') {
      const { items, srcPath, destPath, id } = msg;
      if (!checkSftp(id)) return;

      const moveList = items && Array.isArray(items) && items.length > 0 
        ? items 
        : (srcPath && destPath ? [{ src: srcPath, dest: destPath }] : []);

      if (moveList.length === 0) {
        safeSend({ type: 'sftp-move-res', id, success: false, error: 'No items specified for move' });
        return;
      }

      const escapeShell = (str) => "'" + str.replace(/'/g, "'\\''") + "'";

      // Strategy 1: Fast OS native move via SSH exec
      if (sshClient && isConnected) {
        const mvCmds = moveList.map(item => `mv -f -- ${escapeShell(item.src)} ${escapeShell(item.dest)}`).join(' && ');
        let stderr = '';
        let exitCode = null;
        let finished = false;

        sshClient.exec(mvCmds, (err, stream) => {
          if (err) {
            fallbackSftpMove();
            return;
          }

          const finish = (code) => {
            if (finished) return;
            finished = true;
            const finalCode = (typeof code === 'number') ? code : (typeof exitCode === 'number' ? exitCode : (stderr ? 1 : 0));
            if (finalCode === 0) {
              safeSend({ type: 'sftp-move-res', id, success: true, count: moveList.length });
            } else {
              fallbackSftpMove(stderr || `Move command exited with code ${finalCode}`);
            }
          };

          stream.on('data', () => {});
          stream.stderr.on('data', (d) => { stderr += d.toString(); });
          stream.on('exit', (code) => {
            exitCode = code;
            finish(code);
          });
          stream.on('close', (code) => {
            finish(code);
          });
          stream.resume();
        });
        return;
      }

      fallbackSftpMove();

      function fallbackSftpMove() {
        let index = 0;
        function moveNext() {
          if (index >= moveList.length) {
            safeSend({ type: 'sftp-move-res', id, success: true, count: moveList.length });
            return;
          }
          const current = moveList[index++];
          sftpSession.rename(current.src, current.dest, (err) => {
            if (!err) {
              moveNext();
            } else {
              safeSend({ type: 'sftp-move-res', id, success: false, error: err.message });
            }
          });
        }
        moveNext();
      }
      return;
    }

    // --- SFTP CHMOD ---
    if (type === 'sftp-chmod') {
      const { path: filePath, mode, id } = msg;
      if (!checkSftp(id)) return;

      const numericMode = typeof mode === 'string' ? parseInt(mode, 8) : mode;
      sftpSession.chmod(filePath, numericMode, err => {
        safeSend({ type: 'sftp-chmod-res', id, success: !err, path: filePath, mode, error: err ? err.message : null });
      });
      return;
    }

    // --- SFTP DISK USAGE & STATS (DU) ---
    if (type === 'sftp-du') {
      const { path: targetPath, id } = msg;
      if (!checkSftp(id)) return;

      const escapeShell = (str) => "'" + str.replace(/'/g, "'\\''") + "'";

      const sftpDuRecursive = (targetDir, cb) => {
        let totalBytes = 0;
        let fileCount = 0;
        let dirCount = 0;
        let pending = 1;
        let hasError = null;

        function walk(currentDir) {
          sftpSession.readdir(currentDir, (err, list) => {
            if (err) {
              if (!hasError) hasError = err;
              pending--;
              if (pending === 0) cb(hasError, { size: totalBytes, files: fileCount, dirs: dirCount, isDir: true });
              return;
            }
            const items = (list || []).filter(item => item.filename !== '.' && item.filename !== '..');
            for (const item of items) {
              const itemPath = (currentDir.endsWith('/') ? currentDir : currentDir + '/') + item.filename;
              const isDir = item.attrs ? ((item.attrs.mode & 0o170000) === 0o040000) : false;
              if (isDir) {
                dirCount++;
                pending++;
                walk(itemPath);
              } else {
                fileCount++;
                totalBytes += (item.attrs && item.attrs.size) ? item.attrs.size : 0;
              }
            }
            pending--;
            if (pending === 0) {
              cb(hasError, { size: totalBytes, files: fileCount, dirs: dirCount, isDir: true });
            }
          });
        }

        walk(targetDir);
      };

      if (sshClient && isConnected) {
        const escaped = escapeShell(targetPath);
        const cmd = `if [ -d ${escaped} ]; then
  SIZE=$(du -sb -- ${escaped} 2>/dev/null | cut -f1)
  [ -z "$SIZE" ] && SIZE=$(( $(du -sk -- ${escaped} 2>/dev/null | cut -f1) * 1024 ))
  FILES=$(find ${escaped} -type f 2>/dev/null | wc -l)
  DIRS=$(find ${escaped} -mindepth 1 -type d 2>/dev/null | wc -l)
  echo "{\\"size\\":\${SIZE:-0},\\"files\\":\${FILES:-0},\\"dirs\\":\${DIRS:-0},\\"isDir\\":true}"
else
  SIZE=$(du -sb -- ${escaped} 2>/dev/null | cut -f1)
  [ -z "$SIZE" ] && SIZE=$(stat -c %s ${escaped} 2>/dev/null)
  [ -z "$SIZE" ] && SIZE=0
  echo "{\\"size\\":\${SIZE:-0},\\"files\\":1,\\"dirs\\":0,\\"isDir\\":false}"
fi`;
        sshClient.exec(cmd, (execErr, stream) => {
          if (execErr) {
            return sftpDuRecursive(targetPath, (err, stats) => {
              safeSend({ type: 'sftp-du-res', id, success: !err, path: targetPath, data: stats, error: err ? err.message : null });
            });
          }
          let stdout = '';
          let stderr = '';
          stream.on('data', d => { stdout += d.toString(); });
          stream.stderr.on('data', d => { stderr += d.toString(); });
          stream.on('close', code => {
            if (code === 0 && stdout.trim()) {
              try {
                const data = JSON.parse(stdout.trim());
                safeSend({ type: 'sftp-du-res', id, success: true, path: targetPath, data, error: null });
              } catch (e) {
                sftpDuRecursive(targetPath, (err, stats) => {
                  safeSend({ type: 'sftp-du-res', id, success: !err, path: targetPath, data: stats, error: err ? err.message : null });
                });
              }
            } else {
              sftpDuRecursive(targetPath, (err, stats) => {
                safeSend({ type: 'sftp-du-res', id, success: !err, path: targetPath, data: stats, error: err ? err.message : null });
              });
            }
          });
        });
      } else {
        sftpSession.stat(targetPath, (sErr, stats) => {
          if (sErr) {
            safeSend({ type: 'sftp-du-res', id, success: false, path: targetPath, error: sErr.message });
            return;
          }
          const isDir = (stats.mode & 0o170000) === 0o040000;
          if (isDir) {
            sftpDuRecursive(targetPath, (err, duStats) => {
              safeSend({ type: 'sftp-du-res', id, success: !err, path: targetPath, data: duStats, error: err ? err.message : null });
            });
          } else {
            safeSend({
              type: 'sftp-du-res',
              id,
              success: true,
              path: targetPath,
              data: { size: stats.size, files: 1, dirs: 0, isDir: false },
              error: null
            });
          }
        });
      }
      return;
    }

    // --- SFTP EXTRACT ARCHIVE ---
    if (type === 'sftp-extract') {
      const { path: archivePath, dir: destDir, id } = msg;
      if (!sshClient || !isConnected) {
        safeSend({ type: 'sftp-extract-res', id, success: false, error: 'SSH connection not active' });
        return;
      }

      const escapeShell = (str) => "'" + str.replace(/'/g, "'\\''") + "'";
      const targetArchive = escapeShell(archivePath);
      const destination = escapeShell(destDir || '.');
      const lower = archivePath.toLowerCase();
      let cmd = '';

      if (lower.endsWith('.zip')) {
        cmd = `if command -v unzip >/dev/null 2>&1; then unzip -o ${targetArchive} -d ${destination}; elif command -v 7z >/dev/null 2>&1; then 7z x -y -o${destination} ${targetArchive}; elif command -v python3 >/dev/null 2>&1; then python3 -c "import zipfile; zipfile.ZipFile(${targetArchive}).extractall(${destination})"; elif command -v python >/dev/null 2>&1; then python -c "import zipfile; zipfile.ZipFile(${targetArchive}).extractall(${destination})"; else echo "Error: Neither unzip, 7z, nor python is installed on the remote server." >&2; exit 127; fi`;
      } else if (lower.endsWith('.tar.gz') || lower.endsWith('.tgz')) {
        cmd = `if command -v tar >/dev/null 2>&1; then tar -xzf ${targetArchive} -C ${destination}; else echo "Error: tar is not installed on the remote server." >&2; exit 127; fi`;
      } else if (lower.endsWith('.tar.bz2') || lower.endsWith('.tbz2')) {
        cmd = `if command -v tar >/dev/null 2>&1; then tar -xjf ${targetArchive} -C ${destination}; else echo "Error: tar is not installed on the remote server." >&2; exit 127; fi`;
      } else if (lower.endsWith('.tar.xz') || lower.endsWith('.txz')) {
        cmd = `if command -v tar >/dev/null 2>&1; then tar -xJf ${targetArchive} -C ${destination}; else echo "Error: tar is not installed on the remote server." >&2; exit 127; fi`;
      } else if (lower.endsWith('.tar')) {
        cmd = `if command -v tar >/dev/null 2>&1; then tar -xf ${targetArchive} -C ${destination}; else echo "Error: tar is not installed on the remote server." >&2; exit 127; fi`;
      } else if (lower.endsWith('.gz')) {
        cmd = `if command -v gunzip >/dev/null 2>&1; then cd ${destination} && gunzip -k ${targetArchive}; elif command -v gzip >/dev/null 2>&1; then cd ${destination} && gzip -dk ${targetArchive}; else echo "Error: gzip/gunzip is not installed on the remote server." >&2; exit 127; fi`;
      } else if (lower.endsWith('.7z')) {
        cmd = `if command -v 7z >/dev/null 2>&1; then 7z x -y -o${destination} ${targetArchive}; else echo "Error: 7z is not installed on the remote server." >&2; exit 127; fi`;
      } else if (lower.endsWith('.rar')) {
        cmd = `if command -v unrar >/dev/null 2>&1; then unrar x -o+ ${targetArchive} ${destination}; elif command -v 7z >/dev/null 2>&1; then 7z x -y -o${destination} ${targetArchive}; else echo "Error: unrar or 7z is not installed on the remote server." >&2; exit 127; fi`;
      } else {
        safeSend({ type: 'sftp-extract-res', id, success: false, error: 'Unsupported archive format. Supported formats: .zip, .tar, .tar.gz, .tgz, .tar.bz2, .tar.xz, .gz, .7z, .rar' });
        return;
      }

      sshClient.exec(cmd, (err, stream) => {
        if (err) {
          safeSend({ type: 'sftp-extract-res', id, success: false, error: err.message });
          return;
        }

        let stdout = '';
        let stderr = '';

        stream.on('data', (d) => { stdout += d.toString(); });
        stream.stderr.on('data', (d) => { stderr += d.toString(); });

        stream.on('close', (code) => {
          if (code === 0) {
            safeSend({ type: 'sftp-extract-res', id, success: true, message: 'Archive extracted successfully.', output: stdout });
          } else {
            safeSend({ type: 'sftp-extract-res', id, success: false, error: stderr.trim() || stdout.trim() || `Command exited with code ${code}` });
          }
        });
      });
      return;
    }

    // --- SFTP COMPRESS ARCHIVE ---
    if (type === 'sftp-compress') {
      const { dir: currentDir, files: fileNames, archiveName, format, id } = msg;
      if (!sshClient || !isConnected) {
        safeSend({ type: 'sftp-compress-res', id, success: false, error: 'SSH connection not active' });
        return;
      }

      if (!Array.isArray(fileNames) || fileNames.length === 0) {
        safeSend({ type: 'sftp-compress-res', id, success: false, error: 'No files specified for compression' });
        return;
      }

      const escapeShell = (str) => "'" + str.replace(/'/g, "'\\''") + "'";
      const destDir = escapeShell(currentDir || '.');
      const safeArchive = escapeShell(archiveName);
      const safeFiles = fileNames.map(f => escapeShell(f)).join(' ');

      let cmd = '';
      if (format === 'zip' || (archiveName && archiveName.toLowerCase().endsWith('.zip'))) {
        cmd = `if command -v zip >/dev/null 2>&1; then cd ${destDir} && zip -r ${safeArchive} ${safeFiles}; elif command -v 7z >/dev/null 2>&1; then cd ${destDir} && 7z a ${safeArchive} ${safeFiles}; elif command -v python3 >/dev/null 2>&1; then cd ${destDir} && python3 -c "import zipfile, sys; z = zipfile.ZipFile(sys.argv[1], 'w', zipfile.ZIP_DEFLATED); [z.write(f) for f in sys.argv[2:]]; z.close()" ${safeArchive} ${safeFiles}; else echo "Error: zip or 7z is not installed on the remote server." >&2; exit 127; fi`;
      } else {
        cmd = `if command -v tar >/dev/null 2>&1; then cd ${destDir} && tar -czf ${safeArchive} ${safeFiles}; else echo "Error: tar is not installed on the remote server." >&2; exit 127; fi`;
      }

      sshClient.exec(cmd, (err, stream) => {
        if (err) {
          safeSend({ type: 'sftp-compress-res', id, success: false, error: err.message });
          return;
        }

        let stdout = '';
        let stderr = '';

        stream.on('data', (d) => { stdout += d.toString(); });
        stream.stderr.on('data', (d) => { stderr += d.toString(); });

        stream.on('close', (code) => {
          if (code === 0) {
            safeSend({ type: 'sftp-compress-res', id, success: true, message: 'Archive created successfully.', output: stdout });
          } else {
            safeSend({ type: 'sftp-compress-res', id, success: false, error: stderr.trim() || stdout.trim() || `Compression failed with code ${code}` });
          }
        });
      });
      return;
    }

    // --- SFTP DOWNLOAD DIRECTORY (AUTO ZIP & STREAM CHUNKS) ---
    if (type === 'sftp-download-dir') {
      const { path: dirPath, id } = msg;
      if (!checkSftp(id)) return;

      if (!sshClient || !isConnected) {
        safeSend({ type: 'sftp-download-dir-res', id, success: false, error: 'SSH connection not active for directory compression' });
        return;
      }

      const escapeShell = (str) => "'" + str.replace(/'/g, "'\\''") + "'";
      const folderName = path.basename(dirPath) || 'folder';
      const parentDir = path.dirname(dirPath) || '.';
      const randomSuffix = Date.now() + '_' + Math.random().toString(36).substring(2, 8);
      const tempZipBase = `/tmp/sftp_dl_${randomSuffix}`;
      const tempZipPath = `${tempZipBase}.zip`;

      const escapedParent = escapeShell(parentDir);
      const escapedFolder = escapeShell(folderName);
      const escapedZip = escapeShell(tempZipPath);

      safeSend({ type: 'sftp-download-dir-progress', id, message: 'Initiating compression...' });

      const cmd = `if command -v zip >/dev/null 2>&1; then
  cd ${escapedParent} && zip -r -q ${escapedZip} ${escapedFolder} && echo "zip"
elif command -v python3 >/dev/null 2>&1; then
  cd ${escapedParent} && python3 -c "import shutil, sys; shutil.make_archive(sys.argv[1].replace('.zip',''), 'zip', sys.argv[2], sys.argv[3])" ${escapedZip} ${escapedParent} ${escapedFolder} && echo "zip"
elif command -v 7z >/dev/null 2>&1; then
  cd ${escapedParent} && 7z a ${escapedZip} ${escapedFolder} && echo "zip"
else
  cd ${escapedParent} && tar -czf ${escapedZip}.tar.gz ${escapedFolder} && echo "tar"
fi`;

      const compressHeartbeat = setInterval(() => {
        safeSend({ type: 'sftp-download-dir-progress', id, message: 'Compressing directory...' });
      }, 3500);

      sshClient.exec(cmd, (execErr, stream) => {
        if (execErr) {
          clearInterval(compressHeartbeat);
          safeSend({ type: 'sftp-download-dir-res', id, success: false, error: execErr.message });
          return;
        }

        let stdout = '';
        let stderr = '';
        stream.on('data', d => { stdout += d.toString(); });
        stream.stderr.on('data', d => { stderr += d.toString(); });

        stream.on('close', code => {
          clearInterval(compressHeartbeat);

          if (code !== 0) {
            safeSend({ type: 'sftp-download-dir-res', id, success: false, error: stderr.trim() || `Archiving failed with code ${code}` });
            return;
          }

          const isTar = stdout.trim().includes('tar');
          const finalArchivePath = isTar ? `${tempZipPath}.tar.gz` : tempZipPath;
          const downloadFilename = isTar ? `${folderName}.tar.gz` : `${folderName}.zip`;

          sftpSession.stat(finalArchivePath, (sErr, stats) => {
            if (sErr) {
              safeSend({ type: 'sftp-download-dir-res', id, success: false, error: `Archive not found: ${sErr.message}` });
              return;
            }

            const maxLimit = 500 * 1024 * 1024; // 500MB limit
            if (stats.size > maxLimit) {
              sftpSession.unlink(finalArchivePath, () => {});
              safeSend({ type: 'sftp-download-dir-res', id, success: false, error: `Folder archive exceeds maximum download limit (${(stats.size / 1024 / 1024).toFixed(1)} MB > 500 MB)` });
              return;
            }

            safeSend({
              type: 'sftp-download-dir-start',
              id,
              filename: downloadFilename,
              totalSize: stats.size
            });

            let streamedBytes = 0;
            const readStream = sftpSession.createReadStream(finalArchivePath, { chunkSize: 256 * 1024 });

            readStream.on('data', chunk => {
              streamedBytes += chunk.length;
              safeSend({
                type: 'sftp-download-dir-chunk',
                id,
                chunk: chunk.toString('base64'),
                streamedBytes,
                totalBytes: stats.size
              });
            });

            readStream.on('error', readErr => {
              sftpSession.unlink(finalArchivePath, () => {});
              safeSend({ type: 'sftp-download-dir-res', id, success: false, error: readErr.message });
            });

            readStream.on('end', () => {
              sftpSession.unlink(finalArchivePath, () => {});
              safeSend({
                type: 'sftp-download-dir-end',
                id,
                success: true,
                filename: downloadFilename,
                totalSize: stats.size
              });
            });
          });
        });
      });
      return;
    }

    // --- SFTP STAT ---
    if (type === 'sftp-stat') {
      const { path: targetPath, id } = msg;
      if (!checkSftp(id)) return;

      sftpSession.stat(targetPath, (err, stats) => {
        if (err) {
          safeSend({ type: 'sftp-stat-res', id, success: false, error: err.message });
          return;
        }
        safeSend({
          type: 'sftp-stat-res',
          id,
          success: true,
          path: targetPath,
          stat: {
            size: stats.size,
            mode: stats.mode,
            permissions: (stats.mode & 0o777).toString(8),
            uid: stats.uid,
            gid: stats.gid,
            atime: stats.atime,
            mtime: stats.mtime,
            isDirectory: (stats.mode & 0o40000) === 0o40000,
            isFile: (stats.mode & 0o100000) === 0o100000
          }
        });
      });
      return;
    }

    // --- SFTP OPEN WITH EXTERNAL EDITOR (LOCAL BRIDGE & AUTO-SYNC) ---
    if (type === 'sftp-open-external') {
      const { path: targetPath, id, editor = 'default', customCommand = '', autoSync = true } = msg;
      if (!checkSftp(id)) return;

      const filename = path.posix.basename(targetPath);
      const safeDirName = Buffer.from(targetPath).toString('hex').slice(0, 16);
      const localDir = path.join(os.tmpdir(), 'chrome-sftp-cache', safeDirName);

      try {
        fs.mkdirSync(localDir, { recursive: true });
      } catch (dirErr) {
        safeSend({ type: 'sftp-open-external-res', id, success: false, error: 'Cannot create local cache directory: ' + dirErr.message });
        return;
      }

      const localFilePath = path.join(localDir, filename);

      const readStream = sftpSession.createReadStream(targetPath);
      const writeStream = fs.createWriteStream(localFilePath);

      readStream.on('error', (rErr) => {
        safeSend({ type: 'sftp-open-external-res', id, success: false, error: 'SFTP read error: ' + rErr.message });
      });

      writeStream.on('error', (wErr) => {
        safeSend({ type: 'sftp-open-external-res', id, success: false, error: 'Local cache write error: ' + wErr.message });
      });

      writeStream.on('finish', () => {
        const platform = process.platform;
        let execCmd = '';
        let execArgs = [];
        let isDirectExe = false;

        // Custom command or path
        if (editor === 'custom' && customCommand && customCommand.trim()) {
          const raw = customCommand.trim().replace(/^["']|["']$/g, '');
          execCmd = raw;
          execArgs = [localFilePath];
          isDirectExe = fs.existsSync(raw);
        } else if (editor === 'notepad++') {
          if (platform === 'win32') {
            // Check if custom path was specified
            if (customCommand && customCommand.trim() && fs.existsSync(customCommand.trim().replace(/^["']|["']$/g, ''))) {
              execCmd = customCommand.trim().replace(/^["']|["']$/g, '');
              isDirectExe = true;
            } else {
              const candidates = [
                'C:\\Program Files\\Notepad++\\notepad++.exe',
                'C:\\Program Files (x86)\\Notepad++\\notepad++.exe',
                process.env.ProgramFiles ? path.join(process.env.ProgramFiles, 'Notepad++', 'notepad++.exe') : null,
                process.env['ProgramFiles(x86)'] ? path.join(process.env['ProgramFiles(x86)'], 'Notepad++', 'notepad++.exe') : null,
                process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'Programs', 'Notepad++', 'notepad++.exe') : null,
                process.env.APPDATA ? path.join(process.env.APPDATA, 'Notepad++', 'notepad++.exe') : null,
                'D:\\Program Files\\Notepad++\\notepad++.exe',
                'D:\\Program Files (x86)\\Notepad++\\notepad++.exe',
                'D:\\Notepad++\\notepad++.exe',
                'C:\\Notepad++\\notepad++.exe'
              ].filter(Boolean);

              let found = null;
              for (const c of candidates) {
                if (fs.existsSync(c)) {
                  found = c;
                  break;
                }
              }

              // Query Windows Registry App Paths if not found in standard directories
              if (!found) {
                try {
                  const { execSync } = require('child_process');
                  const out = execSync('reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\notepad++.exe" /ve', { timeout: 1500, stdio: ['ignore', 'pipe', 'ignore'] }).toString();
                  const m = out.match(/REG_SZ\s+(.*)$/m);
                  if (m && m[1]) {
                    const regP = m[1].trim().replace(/^["']|["']$/g, '');
                    if (fs.existsSync(regP)) found = regP;
                  }
                } catch (e) {}
              }

              if (!found) {
                try {
                  const { execSync } = require('child_process');
                  const out = execSync('reg query "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\notepad++.exe" /ve', { timeout: 1500, stdio: ['ignore', 'pipe', 'ignore'] }).toString();
                  const m = out.match(/REG_SZ\s+(.*)$/m);
                  if (m && m[1]) {
                    const regP = m[1].trim().replace(/^["']|["']$/g, '');
                    if (fs.existsSync(regP)) found = regP;
                  }
                } catch (e) {}
              }

              if (found) {
                execCmd = found;
                isDirectExe = true;
              } else {
                execCmd = 'notepad++';
                isDirectExe = false;
              }
            }
          } else {
            // Linux candidates
            const linuxCandidates = [
              '/snap/bin/notepad-plus-plus',
              '/usr/bin/notepad-plus-plus',
              '/usr/bin/notepadqq',
              '/snap/bin/notepadqq',
              '/usr/bin/gedit'
            ];
            let found = null;
            for (const c of linuxCandidates) {
              if (fs.existsSync(c)) { found = c; break; }
            }
            execCmd = found || 'notepadqq';
            isDirectExe = !!found;
          }
          execArgs = [localFilePath];
        } else if (editor === 'vscode') {
          if (platform === 'win32') {
            const candidates = [
              process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'Programs', 'Microsoft VS Code', 'Code.exe') : null,
              'C:\\Program Files\\Microsoft VS Code\\Code.exe',
              'C:\\Program Files (x86)\\Microsoft VS Code\\Code.exe',
              process.env.ProgramFiles ? path.join(process.env.ProgramFiles, 'Microsoft VS Code', 'Code.exe') : null
            ].filter(Boolean);

            let found = null;
            for (const c of candidates) {
              if (fs.existsSync(c)) { found = c; break; }
            }
            if (found) {
              execCmd = found;
              isDirectExe = true;
            } else {
              execCmd = 'code.cmd';
              isDirectExe = false;
            }
          } else {
            execCmd = 'code';
            isDirectExe = false;
          }
          execArgs = [localFilePath];
        } else if (editor === 'sublime') {
          if (platform === 'win32') {
            const candidates = [
              'C:\\Program Files\\Sublime Text\\sublime_text.exe',
              'C:\\Program Files\\Sublime Text 3\\sublime_text.exe',
              'C:\\Program Files (x86)\\Sublime Text\\sublime_text.exe'
            ];
            let found = null;
            for (const c of candidates) {
              if (fs.existsSync(c)) { found = c; break; }
            }
            if (found) {
              execCmd = found;
              isDirectExe = true;
            } else {
              execCmd = 'subl';
              isDirectExe = false;
            }
          } else {
            execCmd = 'subl';
            isDirectExe = false;
          }
          execArgs = [localFilePath];
        } else if (editor === 'notepad') {
          if (platform === 'win32') {
            execCmd = 'notepad.exe';
            isDirectExe = true;
            execArgs = [localFilePath];
          } else if (platform === 'darwin') {
            execCmd = 'open';
            execArgs = ['-e', localFilePath];
          } else {
            execCmd = 'gedit';
            execArgs = [localFilePath];
          }
        } else {
          // Default system application
          if (platform === 'win32') {
            execCmd = 'cmd.exe';
            execArgs = ['/c', 'start', '""', localFilePath];
          } else if (platform === 'darwin') {
            execCmd = 'open';
            execArgs = [localFilePath];
          } else {
            execCmd = 'xdg-open';
            execArgs = [localFilePath];
          }
        }

        // Spawn process reliably
        let child = null;
        let launchError = null;

        try {
          if (platform === 'win32') {
            if (isDirectExe) {
              // Direct execution without cmd.exe -> Completely immune to spaces and quote bugs!
              child = spawn(execCmd, execArgs, {
                detached: true,
                stdio: 'ignore',
                shell: false
              });
            } else if (execCmd === 'cmd.exe') {
              child = spawn(execCmd, execArgs, {
                detached: true,
                stdio: 'ignore',
                shell: false
              });
            } else {
              // Named command like notepad++ or code.cmd -> Use powershell Start-Process with fallback
              const escapedPath = localFilePath.replace(/'/g, "''");
              const psScript = `Start-Process -FilePath "${execCmd}" -ArgumentList @('${escapedPath}')`;
              child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', psScript], {
                detached: true,
                stdio: 'ignore',
                shell: false
              });
            }
          } else {
            // Linux / macOS
            child = spawn(execCmd, execArgs, {
              detached: true,
              stdio: 'ignore',
              shell: false
            });
          }

          child.on('error', (spawnErr) => {
            console.error('[External Editor Error]:', spawnErr.message);
            launchError = spawnErr;
          });

          child.unref();
        } catch (spawnEx) {
          launchError = spawnEx;
        }

        setTimeout(() => {
          if (launchError) {
            safeSend({
              type: 'sftp-open-external-res',
              id,
              success: false,
              error: `Failed to launch ${editor}: ${launchError.message}. If installed in a non-standard path, please enter the full path in Custom Command.`
            });
            return;
          }

          // Set up auto-sync watcher
          if (autoSync) {
            if (activeExternalWatchers.has(targetPath)) {
              const old = activeExternalWatchers.get(targetPath);
              if (old && old.watcher) {
                try { old.watcher.close(); } catch (e) {}
              }
              activeExternalWatchers.delete(targetPath);
            }

            let debounceTimer = null;
            let isUploading = false;
            let lastMtime = 0;
            try {
              lastMtime = fs.statSync(localFilePath).mtimeMs;
            } catch (e) {}

            try {
              const watcher = fs.watch(localFilePath, (eventType) => {
                if (eventType === 'change') {
                  if (debounceTimer) clearTimeout(debounceTimer);
                  debounceTimer = setTimeout(() => {
                    try {
                      if (!fs.existsSync(localFilePath)) return;
                      const curStat = fs.statSync(localFilePath);
                      if (curStat.mtimeMs <= lastMtime) return;
                      lastMtime = curStat.mtimeMs;
                      if (isUploading) return;
                      isUploading = true;

                      const rLocal = fs.createReadStream(localFilePath);
                      const wRemote = sftpSession.createWriteStream(targetPath);
                      rLocal.pipe(wRemote);

                      wRemote.on('close', () => {
                        isUploading = false;
                        safeSend({
                          type: 'sftp-external-synced',
                          path: targetPath,
                          filename,
                          size: curStat.size,
                          mtime: curStat.mtimeMs
                        });
                      });

                      wRemote.on('error', (upErr) => {
                        isUploading = false;
                        console.error('[Auto-Sync SFTP Upload Error]:', upErr.message);
                      });
                    } catch (syncErr) {
                      isUploading = false;
                    }
                  }, 600);
                }
              });

              activeExternalWatchers.set(targetPath, { watcher, localFilePath });
            } catch (watchErr) {
              console.warn('[External Watcher Warning]:', watchErr.message);
            }
          }

          safeSend({
            type: 'sftp-open-external-res',
            id,
            success: true,
            path: targetPath,
            localPath: localFilePath,
            editor,
            autoSync: !!autoSync
          });
        }, 350);
      });

      readStream.pipe(writeStream);
      return;
    }

    // --- SFTP STOP EXTERNAL WATCHER ---
    if (type === 'sftp-stop-external') {
      const { path: targetPath, id } = msg;
      if (activeExternalWatchers.has(targetPath)) {
        const item = activeExternalWatchers.get(targetPath);
        if (item && item.watcher) {
          try { item.watcher.close(); } catch (e) {}
        }
        activeExternalWatchers.delete(targetPath);
      }
      safeSend({ type: 'sftp-stop-external-res', id, success: true });
      return;
    }
  });

  ws.on('close', () => {
    console.log(`[WS] Client disconnected (${clientIp})`);
    clearInterval(pingInterval);
    cleanupSSH();
  });

  ws.on('error', (err) => {
    console.error(`[WS Error] ${clientIp}:`, err.message);
    cleanupSSH();
  });
});

server.listen(PORT, HOST, () => {
  console.log(`====================================================`);
  console.log(`🚀 Chrome SSH & SFTP Bridge Server is RUNNING!`);
  console.log(`📡 HTTP Server: http://${HOST}:${PORT}`);
  console.log(`⚡ WebSocket URL: ws://${HOST}:${PORT}/ws`);
  console.log(`====================================================`);
});
